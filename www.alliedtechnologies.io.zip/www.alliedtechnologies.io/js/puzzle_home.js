//Creating maths puzzle for allied forms



//vars for quote forms

var input1 = document.querySelector('#puzzle_input1');

var input2 = document.querySelector('#puzzle_input2');

var input3 = document.querySelector('#puzzle_input3');

var quote_form = document.querySelector('#myform');



//vars for sticky forms

var sticky_input1 = document.querySelector('#sticky_input1');

var sticky_input2 = document.querySelector('#sticky_input2');

var sticky_input3 = document.querySelector('#sticky_input3');

var sticky_puzzle_form = document.querySelector('#sticky_puzzle_form');



//CREATE PUZZLES

function createPuzzle() {

    //create puzzle for quote form

    value_one = Math.floor(Math.random() * 10);

    value_two = Math.floor(Math.random() * 10);

    input1.value = value_one;

    input2.value = value_two;



    //create puzzle for sticky form

    sticky_value_one = Math.floor(Math.random() * 10);

    sticky_value_two = Math.floor(Math.random() * 10);

    sticky_input1.value = sticky_value_one;

    sticky_input2.value = sticky_value_two;

}



// Check result for quote form

function checkResult() {

    event.preventDefault();

    // var country_code = document.getElementById('country_code');
    //  var code = document.getElementById('code').innerHTML;
    //  country_code.value = code;

    sum_result = parseInt(input1.value) + parseInt(input2.value);

    if (input3.value == sum_result) {

        document.querySelector('#puzzle_alert').classList.replace('alert-danger', 'alert-success');

        document.querySelector('#puzzle_alert').style.display = 'block';

        document.querySelector('#puzzle_alert').innerHTML = "Submitting...";

        quote_form.submit();

    } else {

        document.querySelector('#puzzle_alert').style.display = 'block';

    }

}



//Check Result for top form

function checkTopFormResult() {

    event.preventDefault();

    sum_result = parseInt(top_input1.value) + parseInt(top_input2.value);

    if (top_input3.value == sum_result) {

        document.querySelector('#top_puzzle_alert').classList.replace('alert-danger', 'alert-success');

        document.querySelector('#top_puzzle_alert').style.display = 'block';

        document.querySelector('#top_puzzle_alert').innerHTML = "Submitting...";

        top_form.submit();

    } else {

        document.querySelector('#top_puzzle_alert').style.display = 'block';

    }

}



//Check Result for sticky form

function checkStickyFormResult() {

    event.preventDefault();

    sum_result = parseInt(sticky_input1.value) + parseInt(sticky_input2.value);

    if (sticky_input3.value == sum_result) {

        document.querySelector('#sticky_puzzle_alert').classList.replace('alert-danger', 'alert-success');

        document.querySelector('#sticky_puzzle_alert').style.display = 'block';

        document.querySelector('#sticky_puzzle_alert').innerHTML = "Submitting...";

        sticky_puzzle_form.submit();

    } else {

        document.querySelector('#sticky_puzzle_alert').style.display = 'block';

    }

}





//Remove danger when re-entering puzzle result

//Quoteform

input3.addEventListener('keyup', function() {

    document.querySelector('#puzzle_alert').style.display = 'none';

});

//Top form

top_input3.addEventListener('keyup', function() {

    document.querySelector('#top_puzzle_alert').style.display = 'none';

});



//Sticky form

sticky_input3.addEventListener('keyup', function() {

    document.querySelector('#sticky_puzzle_alert').style.display = 'none';

})