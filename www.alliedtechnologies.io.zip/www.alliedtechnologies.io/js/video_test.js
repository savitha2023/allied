$(".vidloadmorebtn").click(function() {
    var vidshowmore = document.querySelector("#vidshowmore");
    if (vidshowmore.style.height == "0px") {
        vidshowmore.style.height = "auto";
        this.innerHTML = "Show Less Reviews ...";
    } else {
        vidshowmore.style.height = "0px";
        this.innerHTML = "Show More Reviews ...";
    }
})