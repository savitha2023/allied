var solphone = document.querySelector(".solphone");
window.intlTelInput(solphone, {
    // allowDropdown: false,
    // autoHideDialCode: false,
    // autoPlaceholder: "off",
    // dropdownContainer: document.body,
    // excludeCountries: ["us"],
    // formatOnDisplay: false,
    initialCountry: "auto",
    geoIpLookup: function(callback) {
        $.get("https://ipinfo.io", function() {}, "jsonp").always(function(resp) {
            var countryCode = (resp && resp.country) ? resp.country : "";
            callback(countryCode);
        });
    },
    hiddenInput: "full_number",
    // localizedCountries: { 'de': 'Deutschland' },
    // nationalMode: false,
    // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
    // placeholderNumberType: "MOBILE",
    // preferredCountries: ['cn', 'jp'],
    // separateDialCode: true,
    utilsScript: "build/js/utils.js",
});



$(document).ready(function() {
    $.get("https://ipinfo.io", function() {}, "jsonp").always(function(resp) {
        var countryCode1 = (resp && resp.country) ? resp.country : "";
        var ccode = document.querySelector("#ccode");
        ccode.value = countryCode1;
    });
})



var solpopsubmitbtn = document.querySelector("#solpopsubmitbtn");

function popdeactivate() {
    solpopsubmitbtn.value = "Submitting...";
    solpopsubmitbtn.classList.add("solsubmit");
    solpopsubmitbtn.disabled = true;
}